package com.company;

public interface FabricaComprable {
}
