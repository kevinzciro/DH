package com.company;

public interface Figuras {

    public double calcularArea();
}
